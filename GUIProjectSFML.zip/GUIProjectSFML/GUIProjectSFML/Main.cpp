#include <SFML/Graphics.hpp>
#include <iostream>
#include "Button.h"
#include "Switch.h"
#include "Checkbox.h"

using namespace std;

int main() {
	// Create window
	sf::RenderWindow window;
	window.create(sf::VideoMode(600, 800), "Test", sf::Style::Titlebar | sf::Style::Close); // Unresizable window with titlebar
	window.setFramerateLimit(60);

	// Create elements
	// Set the pointer of the new Button in the ram
	Button* btn1 = new Button("Unresponsive");
	btn1->setPosition(300.f - (btn1->getWidth() + 10), 100.f);
	Button* btn2 = new Button("Actionless");
	btn2->setPosition(300.f + 10, 100.f);
	/// btn1.setPosition(20.f, 780.f - btn1.height()); // Bottom left
	Switch* sw1 = new Switch("Do jack shit");
	sw1->setPosition(20.f, 50.f);
	Checkbox* chbox1 = new Checkbox("This does fuck all");
	chbox1->setPosition(20.f, 170.f);

	while (window.isOpen())
	{
		// Take event
		sf::Event event;
		// Loop to handle event
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed) { // When close button is pressed
				window.close();
			}
			if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) { // When mouse button 1 is pressed
				// Handle elements
				if (btn1->isPressed() == true) {}
				if (btn2->isPressed() == true) {}
				if (sw1->isPressed() == true) {}
				if (chbox1->isPressed() == true) {}

				cout << "Event: Mouse Button Pressed" << endl;
				cout << "X: " << event.mouseButton.x << "\t";
				cout << "Y: " << event.mouseButton.y << endl;
			}
			if (event.type == sf::Event::MouseButtonReleased && event.mouseButton.button == sf::Mouse::Left) { // When mouse button 1 is released
				// Handle elements
				if (btn1->isPressed(2) == true) {
					// Code executed when this button has been pressed
					cout << "Button 1 was pressed" << endl;
				}
				if (btn2->isPressed(2) == true) {
					// Code executed when this button has been pressed
					cout << "Button 2 was pressed" << endl;
				}
				if (sw1->isPressed(2) == true) {}
				if (chbox1->isPressed(2) == true) {}

				cout << "Event: Mouse Button Released" << endl;
				cout << "X: " << event.mouseButton.x << "\t";
				cout << "Y: " << event.mouseButton.y << endl;
			}
			if (event.type == sf::Event::MouseMoved) { // When mouse is moved
				// Handle elements
				if (btn1->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
				if (btn2->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
				if (sw1->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
				if (chbox1->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
			}

		}

		// Update elements
		btn1->upt();
		btn2->upt();
		sw1->upt();
		chbox1->upt();

		// Draw everything

		//sf::Sprite* sprites[20];
		//for (int i = 0; i < 20; i++)
		//{
		//	window.draw(sprites[i]);
		//}

		window.clear(sf::Color::White);
		window.draw(btn1->getSprite());
		window.draw(btn1->getLabel());
		window.draw(btn2->getSprite());
		window.draw(btn2->getLabel());
		window.draw(sw1->getSprite());
		window.draw(sw1->getSprite(2));
		window.draw(sw1->getLabel());
		window.draw(sw1->getLabel(2));
		window.draw(chbox1->getSprite());
		window.draw(chbox1->getSprite(2));
		window.draw(chbox1->getSprite(3));
		window.draw(chbox1->getLabel());
		window.display();
	}

	/*
	btn1->setDisabled(true);

	if (btn1->getDisabled()) {
		cout << "Button is disabled" << endl;
	}

	btn1->setDisabled(false);

	if (!btn1->getDisabled()) {
		cout << "Button is not disabled" << endl;
	}

	btn1->setHidden(true);

	if (btn1->getHidden()) {
		cout << "Button is hidden" << endl;
	}

	btn1->setHidden(false);

	if (!btn1->getHidden()) {
		cout << "Button is not hidden" << endl;
	}
	*/

	//Reset the reserved ram and set the address pointer to NULL
	delete(btn1);
	btn1 = NULL;
	delete(btn2);
	btn2 = NULL;

	return 0;
}