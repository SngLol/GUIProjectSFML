#include <SFML/Graphics.hpp>
#include <iostream>
#include "Button.h"
#include "Switch.h"
#include "Checkbox.h"

using namespace std;

int main() {
	// Create window
	sf::RenderWindow window;
	window.create(sf::VideoMode(600, 800), "Test", sf::Style::Titlebar | sf::Style::Close); // Unresizable window with titlebar
	window.setFramerateLimit(60);

	// Create elements
	// Set the pointer of the new Button in the ram
	Button* btn1 = new Button("Useless Fuck"); // Create and set label of element button/btn1 to "Actionless"

	// Position X explaination: 300 is center of window (x). Subtract 300 by button width divided by 2 for the center of button to match with center of window.
	// Position Y explaination: A Button is 48 pixels in height, A Switch with no label is 30, and the label itself is 40. (48 - 30) / 2 gives the radius difference between 2 circles, 1 with same diameter as height of switch and 1 as height of button. Subtracting this from 40 brings the button center to same height of switch center (subtract another 40 if switch has no label). Add 10 because switch draw position (y) is 10
	btn1->setPosition(300.f - (btn1->getWidth() / 2), 41.f);

	Button* btn2 = new Button("Unwork");
	btn2->setPosition(300.f - (btn2->getWidth() / 2), 141.f); // Adding 100 to y position gives a nice space between elements
	btn2->setDisabled(true); // Make this element uninterractable

	Switch* sw1 = new Switch("Do jack shit");
	sw1->setPosition(20.f, 10.f); // Switch element has a height of 70 pixels (30 with no label). 30 empty pixels underneeth before next element brings a nicer look. Total height per element adds up to 100 for easy head calculation
	
	Switch* sw2 = new Switch("This bitch disabled");
	sw2->setPosition(20.f, 110.f); // 100 pixels below previous element to fullfill the criteria for 'a nicer look'
	sw2->setDisabled(true);
	
	Checkbox* chbox1 = new Checkbox("This does fuck all");
	chbox1->setPosition(20.f, 250.f); // Add 40 to y position because checkbox element has no label on top as the switch does. Therefor keeping the space between the clickable elements themselves the same.

	// Det �r roligt med knappar
	Button* btnD = new Button("Det", "", "", false);
	btnD->setPosition(17.f, 783.f - btnD->getHeight());
	btnD->setDisabled(true);

	Button* btn� = new Button("�r", "", "", false);
	btn�->setPosition(btnD->getWidth() + 25.f + btnD->getPosition().x, 783.f - btn�->getHeight());
	btn�->setDisabled(true);

	Button* btnR = new Button("Roligt", "", "", false);
	btnR->setPosition(btn�->getWidth() + 25.f + btn�->getPosition().x, 783.f - btnR->getHeight());
	btnR->setDisabled(true);

	Button* btnM = new Button("Med", "", "", false);
	btnM->setPosition(btnR->getWidth() + 25.f + btnR->getPosition().x, 783.f - btnM->getHeight());
	btnM->setDisabled(true);

	Button* btnK = new Button("Knappar", "", "", false);
	btnK->setPosition(btnM->getWidth() + 25.f + btnM->getPosition().x, 783.f - btnK->getHeight());
	btnK->setDisabled(true);

	while (window.isOpen())
	{
		// Element changes
		if (sw1->isOn()) {
			btn2->setDisabled(false);
			sw2->setDisabled(false);
		}
		else {
			btn2->setDisabled(true);
			sw2->setDisabled(true);
		}

		if (chbox1->isOn()) {
			btnD->setDisabled(false);
			btn�->setDisabled(false);
			btnR->setDisabled(false);
			btnM->setDisabled(false);
			btnK->setDisabled(false);
		}
		else {
			btnD->setDisabled(true);
			btn�->setDisabled(true);
			btnR->setDisabled(true);
			btnM->setDisabled(true);
			btnK->setDisabled(true);
		}

		// Take event
		sf::Event event;
		// Loop to handle event
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed) { // When close button is pressed
				window.close();
			}
			if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) { // When mouse button 1 is pressed
				// Handle elements
				if (btn1->isPressed() == true) {}
				if (btn2->isPressed() == true) {}
				if (sw1->isPressed() == true) {}
				if (sw2->isPressed() == true) {}
				if (chbox1->isPressed() == true) {}

				if (btnD->isPressed() == true) {}
				if (btn�->isPressed() == true) {}
				if (btnR->isPressed() == true) {}
				if (btnM->isPressed() == true) {}
				if (btnK->isPressed() == true) {}

				cout << "Event: Mouse Button Pressed" << endl;
				cout << "X: " << event.mouseButton.x << "\t";
				cout << "Y: " << event.mouseButton.y << endl;
			}
			if (event.type == sf::Event::MouseButtonReleased && event.mouseButton.button == sf::Mouse::Left) { // When mouse button 1 is released
				// Handle elements
				if (btn1->isPressed(2) == true) {
					// Code executed when this button has been pressed
					cout << "Button 1 was pressed" << endl;
				}
				cout << (btn2->isPressed(2) == true) << endl;
				if (btn2->isPressed(2) == true) {
					// Code executed when this button has been pressed
					cout << "Button 2 was pressed" << endl;
				}
				if (sw1->isPressed(2) == true) {}
				if (sw2->isPressed(2) == true) {}
				if (chbox1->isPressed(2) == true) {}

				if (btnD->isPressed(2) == true) {}
				if (btn�->isPressed(2) == true) {}
				if (btnR->isPressed(2) == true) {}
				if (btnM->isPressed(2) == true) {}
				if (btnK->isPressed(2) == true) {}

				cout << "Event: Mouse Button Released" << endl;
				cout << "X: " << event.mouseButton.x << "\t";
				cout << "Y: " << event.mouseButton.y << endl;
			}
			if (event.type == sf::Event::MouseMoved) { // When mouse is moved
				// Handle elements
				if (btn1->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
				if (btn2->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
				if (sw1->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
				if (sw2->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
				if (chbox1->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}

				if (btnD->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
				if (btn�->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
				if (btnR->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
				if (btnM->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
				if (btnK->withinBounds(event.mouseMove.x, event.mouseMove.y) == true) {}
			}

		}

		// Update elements
		btn1->upt();
		btn2->upt();
		sw1->upt();
		sw2->upt();
		chbox1->upt();

		btnD->upt();
		btn�->upt();
		btnR->upt();
		btnM->upt();
		btnK->upt();

		// Draw everything

		//sf::Sprite* sprites[20];
		//for (int i = 0; i < 20; i++)
		//{
		//	window.draw(sprites[i]);
		//}

		window.clear(sf::Color::White);
		for (int i = 1; i < 5; i++) {
			window.draw(btn1->getSprite(i));
			window.draw(btn2->getSprite(i));

			window.draw(btnD->getSprite(i));
			window.draw(btn�->getSprite(i));
			window.draw(btnR->getSprite(i));
			window.draw(btnM->getSprite(i));
			window.draw(btnK->getSprite(i));
		}
		window.draw(btn1->getLabel());
		window.draw(btn2->getLabel());

		window.draw(btnD->getLabel());
		window.draw(btn�->getLabel());
		window.draw(btnR->getLabel());
		window.draw(btnM->getLabel());
		window.draw(btnK->getLabel());

		for (int i = 1; i < 3; i++) {
			window.draw(sw1->getSprite(i));
			window.draw(sw1->getLabel(i));
			window.draw(sw2->getSprite(i));
			window.draw(sw2->getLabel(i));
		}

		for (int i = 1; i < 4; i++) {
			window.draw(chbox1->getSprite(i));
		}
		window.draw(chbox1->getLabel());

		window.display();
	}

	/*
	btn1->setDisabled(true);

	if (btn1->getDisabled()) {
		cout << "Button is disabled" << endl;
	}

	btn1->setDisabled(false);

	if (!btn1->getDisabled()) {
		cout << "Button is not disabled" << endl;
	}

	btn1->setHidden(true);

	if (btn1->getHidden()) {
		cout << "Button is hidden" << endl;
	}

	btn1->setHidden(false);

	if (!btn1->getHidden()) {
		cout << "Button is not hidden" << endl;
	}
	*/

	//Reset the reserved ram and set the address pointer to NULL
	delete(btn1);
	btn1 = NULL;
	delete(btn2);
	btn2 = NULL;
	delete(sw1);
	sw1 = NULL;
	delete(sw2);
	sw2 = NULL;
	delete(chbox1);
	chbox1 = NULL;

	return 0;
}