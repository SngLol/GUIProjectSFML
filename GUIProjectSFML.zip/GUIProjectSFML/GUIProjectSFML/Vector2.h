#pragma once
class Vector2{
public:
	Vector2();
	float x;
	float y;
};