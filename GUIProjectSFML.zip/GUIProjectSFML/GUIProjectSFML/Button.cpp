#include "Button.h"

//asign the local variable i_label with the param iLabel etc...
Button::Button(string iLabel, string hLabel, string pLabel) : i_label(iLabel), h_label(hLabel), p_label(pLabel)
{
	//What is going on when we create the button this is your "Create() method"
	cout << "Creating Button..." << endl;
	// disblTex.loadFromFile("btn_disb;.png");
	if (true) {
		idleTex.loadFromFile("btn_idle.png");
		hoverTex.loadFromFile("btn_hover.png");
		pressTex.loadFromFile("btn_press.png");
		Font.loadFromFile("arial.ttf");
	}
	else {
		idleTex.loadFromFile("res/btn_idle.png");
		hoverTex.loadFromFile("res/btn_hover.png");
		pressTex.loadFromFile("res/btn_press.png");
		Font.loadFromFile("res/arial.ttf");
	}
	fSize = 24;
	Label.setFont(Font);
	Label.setCharacterSize(fSize);
	Label.setFillColor(sf::Color::Black);
	Label.setString(i_label);
	cout << Label.getLocalBounds().width << Label.getLocalBounds().height << endl;
	Sprite.setTexture(idleTex);
	if (Label.getLocalBounds().height > fSize * 0.75) {
		fineAdjust = 0;
	}
	else {
		fineAdjust = fSize - (fSize * 0.75);
	}
	upt();
	Label.setOrigin(sf::Vector2f(((Sprite.getLocalBounds().width) / 2 - (Label.getLocalBounds().width) / 2) * (-1), ((Sprite.getLocalBounds().height) / 2 - (Label.getLocalBounds().height + (fSize / 3) + fineAdjust) / 2) * (-1)));
}

void Button::upt() {
	if (Label.getLocalBounds().width > (Sprite.getLocalBounds().width * 0.9)) {
		fSize -= 3;
		Label.setCharacterSize(fSize);
		Label.setString(i_label);
		Label.setOrigin(sf::Vector2f(((Sprite.getLocalBounds().width) / 2 - (Label.getLocalBounds().width) / 2) * (-1), ((Sprite.getLocalBounds().height) / 2 - (Label.getLocalBounds().height + (fSize / 3) + fineAdjust) / 2) * (-1)));
		if (Label.getLocalBounds().width > (Sprite.getLocalBounds().width * 0.9)) {
			upt();
		}
	}
	else {
		if (e_status == Status::disabled) {
			Sprite.setTexture(hoverTex);
			Label.setString(i_label);
		}
	}
}

bool Button::getDisabled() {
	return e_status == Status::disabled;
}

void Button::setDisabled(bool value) {
	if (value) {
		e_status = Status::disabled;
	}
	else {
		e_status = Status::idle;
	}
}

bool Button::getHidden() {
	return e_status == Status::hidden;
}

void Button::setHidden(bool value) {
	if (value) {
		e_status = Status::hidden;
	}
	else {
		e_status = Status::idle;
	}
}

void Button::setPosition(float newX, float newY) {
	pos.x = newX;
	pos.y = newY;
	pos2.x = newX + Sprite.getLocalBounds().width;
	pos2.y = newY + Sprite.getLocalBounds().height;
	Sprite.setPosition(sf::Vector2f(newX, newY));
	Label.setPosition(sf::Vector2f(newX, newY));
}

Vector2 Button::getPosition(){
	return pos;
}

float Button::getHeight() {
	return Sprite.getLocalBounds().height;
}

float Button::getWidth() {
	return Sprite.getLocalBounds().width;
}

sf::Sprite Button::getSprite() {
	return Sprite;
}

sf::Text Button::getLabel() {
	return Label;
}

bool Button::withinBounds(int coorX, int coorY) {
	if (coorX > pos.x && coorX < pos2.x && coorY > pos.y && coorY < pos2.y) {
		if (e_status != Status::press) {
			Sprite.setTexture(hoverTex);
			if (h_label != "") {
				Label.setString(h_label);
			}
			e_status = Status::hover;
		}
		return true;
	}
	else {
		if (e_status != Status::press) {
			Sprite.setTexture(idleTex);
			if (i_label != "") {
				Label.setString(i_label);
			}
		}
		e_status = Status::idle;
		return false;
	}
}

bool Button::isPressed(int x) {
	if (e_status == Status::hover && x == 1) {
		Sprite.setTexture(pressTex);
		if (p_label != "") {
			Label.setString(p_label);
		}
		e_status = Status::press;
		return true;
	}
	else if (e_status == Status::press && x == 2) {
		Sprite.setTexture(hoverTex);
		if (h_label != "") {
			Label.setString(h_label);
		}
		e_status = Status::hover;
		return true;
	}
	else {
		return false;
	}
}